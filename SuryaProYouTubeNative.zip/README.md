# Surya Hacker Pro YouTube — Android wrapper

This is a starter Android Kotlin WebView project for:
`https://youtubepro.suryajasoos-4fe.workers.dev`

## Build
Open this project in Android Studio, or upload the project files to GitHub and use the workflow in `.github/workflows/android.yml`.

## Important limitation
The app enables Android Picture-in-Picture mode when the app reports that a video is active. YouTube's embedded player may still restrict playback in PiP/background on some devices or videos; this starter is not a guarantee of background playback. The Worker page must include the `NativeApp.setVideoActive(true/false)` bridge calls for the native signal to work.
